import { Component, OnInit } from '@angular/core';

@Component({

	selector: 'app-link',
	templateUrl: './link.component.html',
	styleUrls: ['./link.component.scss'],
	standalone: false

}) export class LinkComponent implements OnInit {

	public constructor() {}

	public ngOnInit() {}

}