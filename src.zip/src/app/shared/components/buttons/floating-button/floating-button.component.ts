import { Component, OnInit } from '@angular/core';

@Component({

	selector: 'app-floating-button',
	templateUrl: './floating-button.component.html',
	styleUrls: ['./floating-button.component.scss'],
	standalone: false

}) export class FloatingButtonComponent	implements OnInit {

	public constructor() {}

	public ngOnInit(): void {}

}