import { Component, OnInit } from '@angular/core';

@Component({

	selector: 'app-toggle-translate',
	templateUrl: './toggle-translate.component.html',
	styleUrls: ['./toggle-translate.component.scss'],
	standalone: false

}) export class ToggleTranslateComponent implements OnInit {

	public constructor() {}

	public ngOnInit(): void {}

}