export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyDVIkNai_1zl3tgW2u0QWXcNH3GA2lLj2k",
    authDomain: "wallpaper-be775.firebaseapp.com",
    projectId: "wallpaper-be775",
    storageBucket: "wallpaper-be775.firebasestorage.app",
    messagingSenderId: "299164422775",
    appId: "1:299164422775:web:bb7688af0fe277941b2c72"
  },
  supabase: {
    url: 'https://prhvrlzrmbfwigrkkcwe.supabase.co',
    key: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InByaHZybHpybWJmd2lncmtrY3dlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTg1NTY4MDgsImV4cCI6MjA3NDEzMjgwOH0.s1QUqGBV3TLOa5BdfKGFq2tYf6JTMpcbFgwKBkI8dkw',
  },
  i18n: {
    defaultLang: 'en',
    fallbackLang: 'en',
    supported: ['en', 'es']
  }
};
