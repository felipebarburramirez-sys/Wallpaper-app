
export interface Credential {

	email: string,
	password: string

}