
export interface BucketFile {

	id?: string,
	fullPath: string,
	path: string,
	url: string

}